package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.BoardCell;
import model.Game;
import model.ProcessCellGame;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	/* Remove the following test and add your tests */
	@Test
	public void ProcessCellGameConstructor01() {
		Game game = new ProcessCellGame(5,5,new Random(), 1);
		
		assertTrue(game.getMaxRows() == 5);
		assertTrue(game.getMaxCols() == 5);
	}
	
	@Test 
	public void PCGSetAndGetBoardCell01() {
		Game game = new ProcessCellGame(5,5,new Random(), 1);
		
		game.setBoardCell(1, 1, BoardCell.BLUE);
		assertTrue(game.getBoardCell(1, 1) == BoardCell.BLUE);
		
		try {
			game.setBoardCell(10,0, BoardCell.GREEN);
		} catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void setRow01() {
		Game game = new ProcessCellGame(5,5,new Random(), 1);
		
		game.setRowWithColor(1, BoardCell.BLUE);
		
		for(int col = 0; col < game.getMaxCols(); col++) {
			assertTrue(game.getBoardCell(1, col) == BoardCell.BLUE);
		}
	}
	
	@Test
	public void setCol01() {
		Game game = new ProcessCellGame(5,5,new Random(), 1);
		
		game.setColWithColor(1, BoardCell.RED);
		
		for(int row = 0; row < game.getMaxRows(); row++) {
			assertTrue(game.getBoardCell(row, 1) == BoardCell.RED);
		}
	}
	
	@Test
	public void setBoardWithColor() {
		Game game = new ProcessCellGame(2,2, new Random(), 1);
		
		game.setBoardWithColor(BoardCell.YELLOW);
		
		for(int row = 0; row < 2; row++) {
			for(int col = 0; col < 2; col++) {
				assertTrue(game.getBoardCell(row, col) == BoardCell.YELLOW);
			}
		}
	}
	
	@Test 
	public void isRowEmptyAndIsGameOver01() {
		Game game = new ProcessCellGame(2,2, new Random(), 1);
		
		assertFalse(game.isGameOver());
		
		game.setBoardCell(1, 0, BoardCell.GREEN);
		assertTrue(game.isGameOver());
	}
	
	@Test
	public void ProcessCellGameNextAnimTest01() {
		Game game = new ProcessCellGame(6,6, new Random(1L), 1);
		String answer = "Before Call:\n";
		
		answer += getBoardStr(game);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		answer += "\n" + getBoardStr(game);
		
		System.out.println(answer);
	}
	
	@Test
	public void ProcessCellProcessCell01() {
		Game game = new ProcessCellGame(6,6, new Random(1L), 1);
		String answer = "Before Call:\n";
		
		answer += getBoardStr(game);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		answer += "\nAfter Anim" + getBoardStr(game);
		
		game.processCell(2, 0);
		
		answer += "\nAfter Process (2,0)" + getBoardStr(game);
		
		game.processCell(0, 5);
		
		answer += "\nAfter Process (0,5)" + getBoardStr(game);
		
		game.processCell(1, 2);
		
		answer += "\nAfter Process (1,2)" + getBoardStr(game);
		
		
		System.out.println(answer);
	}
	
	@Test 
	public void CollapseTest01() {
		Game game = new ProcessCellGame(6,6, new Random(1L), 1);
		String answer = "Before Call:\n";
		
		answer += getBoardStr(game);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		answer += "\nAfter Anim" + getBoardStr(game);
		
		game.processCell(2, 0);
		
		answer += "\nAfter Process (2,0)" + getBoardStr(game);
		
		game.processCell(1, 1);
		game.processCell(1, 2);
		game.processCell(1, 3);
		game.processCell(1, 4);
		game.processCell(1, 5);
		game.processCell(1,6);


		answer += "\nAfter Eliminating row 2" + getBoardStr(game);

		System.out.println(answer);
	}
	
	@Test 
	public void CollapseTest02() {
		Game game = new ProcessCellGame(6,6, new Random(1L), 1);
		String answer = "Before Call:\n";
		
		answer += getBoardStr(game);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		answer += "\nAfter Anim" + getBoardStr(game);
		
		game.processCell(0, 0);
		game.processCell(0, 1);
		game.processCell(0, 2);
		game.processCell(0, 4);
		
		answer += "\nBefore Processsing top row\n" + getBoardStr(game);
		
		game.processCell(0, 3);
		
		answer += "\nAfter Process Eliminating 2 rows\n" + getBoardStr(game);
	
		System.out.println(answer);
	}
	
	@Test 
	public void CollapseTest03() {
		Game game = new ProcessCellGame(8, 4, new Random(1L), 1);
		String answer = "Before Call:\n";
		
		answer += getBoardStr(game);
		
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		game.nextAnimationStep();
		
		answer += "\nAfter Anim\n" + getBoardStr(game);
		
		game.processCell(3, 1);
		game.processCell(4,3);
		game.processCell(3, 3);
		
		answer += "\nAfter Process\n" + getBoardStr(game);
		
		game.processCell(4, 2);
		
		answer += "\nAfter Processing 2 rows\n" + getBoardStr(game);
		
		System.out.println(answer);
	}
	
	//Support method from public tests
	private static String getBoardStr(Game game) {
		int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += game.getBoardCell(row, col).getName();
			}
			answer += "\n";
		}

		return answer;
	}
}
